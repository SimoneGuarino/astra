use crate::ui_target_grounding::{
    structured_candidates_from_value, TargetGroundingSource, UITargetCandidate, UITargetRole,
};
use serde::{Deserialize, Serialize};
use serde_json::Value;

const MIN_STRUCTURED_VISION_CONFIDENCE: f32 = 0.35;
const MAX_REASONABLE_SCREEN_COORDINATE: f64 = 100_000.0;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StructuredVisionExtraction {
    pub candidates: Vec<UITargetCandidate>,
    pub rejected: Vec<StructuredVisionRejectedCandidate>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StructuredVisionRejectedCandidate {
    pub reason: String,
    #[serde(default)]
    pub candidate: Value,
}

pub fn parse_structured_vision_candidates(
    content: &str,
    captured_at_ms: u64,
) -> Result<StructuredVisionExtraction, String> {
    let json_text = extract_json_object(content)
        .ok_or_else(|| "structured vision response did not contain a JSON object".to_string())?;
    let parsed: Value = serde_json::from_str(json_text)
        .map_err(|error| format!("structured vision JSON parse failed: {error}"))?;
    let candidates_value = parsed
        .get("ui_candidates")
        .or_else(|| parsed.get("candidates"))
        .ok_or_else(|| "structured vision JSON missing ui_candidates".to_string())?;

    let raw_candidates = candidates_value.as_array().cloned().unwrap_or_else(|| {
        if candidates_value.is_object() {
            vec![candidates_value.clone()]
        } else {
            Vec::new()
        }
    });
    let parsed_candidates = structured_candidates_from_value(
        candidates_value,
        &UITargetRole::Unknown,
        None,
        None,
        TargetGroundingSource::ScreenAnalysis,
    );

    let mut candidates = Vec::new();
    let mut rejected = Vec::new();
    for candidate in parsed_candidates {
        match validate_structured_vision_candidate(candidate, captured_at_ms) {
            Ok(candidate) => candidates.push(candidate),
            Err((reason, candidate)) => rejected.push(StructuredVisionRejectedCandidate {
                reason,
                candidate: candidate.execution_payload(),
            }),
        }
    }

    if parsed_candidates_count(&raw_candidates) > candidates.len() + rejected.len() {
        rejected.push(StructuredVisionRejectedCandidate {
            reason: "one or more raw candidates were malformed before typed parsing".into(),
            candidate: Value::Array(raw_candidates),
        });
    }

    Ok(StructuredVisionExtraction {
        candidates,
        rejected,
    })
}

fn validate_structured_vision_candidate(
    mut candidate: UITargetCandidate,
    captured_at_ms: u64,
) -> Result<UITargetCandidate, (String, UITargetCandidate)> {
    if candidate.role == UITargetRole::Unknown {
        return Err(("candidate role is unsupported or unknown".into(), candidate));
    }
    if candidate.confidence < MIN_STRUCTURED_VISION_CONFIDENCE {
        return Err((
            format!(
                "candidate confidence {:.2} is below structured vision retention threshold {:.2}",
                candidate.confidence, MIN_STRUCTURED_VISION_CONFIDENCE
            ),
            candidate,
        ));
    }
    if !candidate.has_point() {
        return Err((
            "candidate has no explicit point or region".into(),
            candidate,
        ));
    }
    if let Some(region) = candidate.region.as_ref() {
        if region.coordinate_space != "screen" {
            return Err((
                "candidate coordinate space is not executable screen coordinates".into(),
                candidate,
            ));
        }
        for value in [region.x, region.y, region.width, region.height] {
            if !value.is_finite() || value.abs() > MAX_REASONABLE_SCREEN_COORDINATE {
                return Err((
                    "candidate region contains invalid coordinates".into(),
                    candidate,
                ));
            }
        }
    }
    if let Some((x, y)) = candidate.center_point() {
        if !x.is_finite()
            || !y.is_finite()
            || x.abs() > MAX_REASONABLE_SCREEN_COORDINATE
            || y.abs() > MAX_REASONABLE_SCREEN_COORDINATE
        {
            return Err((
                "candidate center contains invalid coordinates".into(),
                candidate,
            ));
        }
    }

    candidate.source = TargetGroundingSource::ScreenAnalysis;
    candidate.observed_at_ms = Some(captured_at_ms);
    candidate.reuse_eligible = true;
    if candidate.rationale.trim().is_empty() {
        candidate.rationale = "Structured vision candidate validated by Rust.".into();
    }

    Ok(candidate)
}

fn parsed_candidates_count(raw_candidates: &[Value]) -> usize {
    raw_candidates
        .iter()
        .filter(|value| value.is_object())
        .count()
}

fn extract_json_object(content: &str) -> Option<&str> {
    let trimmed = content.trim();
    if trimmed.starts_with('{') && trimmed.ends_with('}') {
        return Some(trimmed);
    }

    if let Some(start) = trimmed.find("```json") {
        let after_fence = &trimmed[start + "```json".len()..];
        if let Some(end) = after_fence.find("```") {
            let body = after_fence[..end].trim();
            if body.starts_with('{') && body.ends_with('}') {
                return Some(body);
            }
        }
    }

    let start = trimmed.find('{')?;
    let end = trimmed.rfind('}')?;
    (end > start).then_some(trimmed[start..=end].trim())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_structured_vision_candidate() {
        let extraction = parse_structured_vision_candidates(
            r#"{
                "ui_candidates": [
                    {
                        "candidate_id": "search",
                        "role": "search_input",
                        "region": {"x": 120, "y": 64, "width": 500, "height": 40, "coordinate_space": "screen"},
                        "confidence": 0.88,
                        "provider_hint": "youtube",
                        "supports_focus": true
                    }
                ]
            }"#,
            1_000,
        )
        .expect("parse");

        assert_eq!(extraction.candidates.len(), 1);
        assert_eq!(extraction.candidates[0].observed_at_ms, Some(1_000));
        assert_eq!(extraction.candidates[0].role, UITargetRole::SearchInput);
    }

    #[test]
    fn rejects_low_confidence_candidate() {
        let extraction = parse_structured_vision_candidates(
            r#"{
                "ui_candidates": [
                    {
                        "candidate_id": "weak",
                        "role": "button",
                        "center_x": 20,
                        "center_y": 20,
                        "confidence": 0.2
                    }
                ]
            }"#,
            1_000,
        )
        .expect("parse");

        assert!(extraction.candidates.is_empty());
        assert_eq!(extraction.rejected.len(), 1);
    }

    #[test]
    fn rejects_non_screen_coordinate_space() {
        let extraction = parse_structured_vision_candidates(
            r#"{
                "ui_candidates": [
                    {
                        "candidate_id": "image_space",
                        "role": "ranked_result",
                        "region": {"x": 0.1, "y": 0.2, "width": 0.5, "height": 0.1, "coordinate_space": "normalized"},
                        "confidence": 0.9
                    }
                ]
            }"#,
            1_000,
        )
        .expect("parse");

        assert!(extraction.candidates.is_empty());
        assert_eq!(extraction.rejected.len(), 1);
    }
}
